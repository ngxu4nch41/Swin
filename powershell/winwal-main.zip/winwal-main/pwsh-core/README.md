# PowerShell Core

Contains functionality that is for PowerShell Core.
